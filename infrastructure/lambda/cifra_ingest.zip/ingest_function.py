# Entry point para AWS Lambda
# handler = ingest_function.handler
from ingestion.lambda_handler import handler
